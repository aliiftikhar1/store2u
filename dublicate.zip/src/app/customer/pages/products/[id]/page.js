'use client';

import React, { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import axios from 'axios';
import { motion } from 'framer-motion';
import { FiChevronLeft, FiChevronRight, FiPlusCircle } from 'react-icons/fi';
import { ToastContainer, toast } from 'react-toastify';
import ImageModal from '@/app/customer/components/ImageModal';
import { useDispatch } from 'react-redux';
import { addToCart } from '@/app/store/cartSlice';

const ProductPage = () => {
  const { id } = useParams();
  const router = useRouter();
  const dispatch = useDispatch();
  const [product, setProduct] = useState(null);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [activeTab, setActiveTab] = useState('description'); // State for active tab

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await axios.get(`/api/products/${id}`);
        const { product, relatedProducts } = response.data.data;
  
        // Parse sizes and colors if they are in string format
        const parsedSizes = typeof product.sizes === 'string' ? JSON.parse(product.sizes) : product.sizes;
        const parsedColors = typeof product.colors === 'string' ? JSON.parse(product.colors) : product.colors;
  
        setProduct({
          ...product,
          sizes: parsedSizes,
          colors: parsedColors,
        });
  
        setRelatedProducts(relatedProducts);
      } catch (error) {
        console.error('Error fetching product:', error);
      }
    };
  
    if (id) {
      fetchProduct();
    }
  }, [id]);
  

  const handleAddToCart = (product) => {
    if (!selectedSize || !selectedColor) {
      toast.error('Please select a size and color.');
      return;
    }
  
    dispatch(addToCart({
      productId: product.id,
      quantity: 1,
      price: product.price,
      selectedColor: selectedColor,  // Ensure selectedColor is captured here
      selectedSize: selectedSize,    // Ensure selectedSize is captured here
      images: product.images,
      name: product.name,
    }));
    toast.success(`${product.name} added to cart!`);
  };
  

  const getImageUrl = (url) => {
    return `https://data.tascpa.ca/uploads/${url}`;
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % product.images.length);
  };

  const handlePreviousImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex - 1 + product.images.length) % product.images.length);
  };

  const handleThumbnailClick = (index) => {
    setCurrentImageIndex(index);
  };

  const handleRelatedProductClick = (id) => {
    router.push(`/customer/pages/products/${id}`);
  };

  const handleImageClick = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  if (!product) {
    return <div className="text-center py-8">Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-wrap pt-4">
        <div className="w-full lg:w-1/2 mb-8 lg:mb-0 flex">
          <div className="flex flex-col justify-center items-center mr-4">
            {product.images && product.images.map((image, index) => (
              <img
                key={index}
                src={getImageUrl(image.url)}
                alt={product.name}
                className={`w-20 h-20 object-cover mb-2 cursor-pointer ${index === currentImageIndex ? 'opacity-100' : 'opacity-50'}`}
                onClick={() => handleThumbnailClick(index)}
              />
            ))}
          </div>
          <div className="relative pl-4 right-0">
            {product.images && product.images.length > 0 ? (
              <>
                <motion.img
                  key={currentImageIndex}
                  src={getImageUrl(product.images[currentImageIndex].url)}
                  alt={product.name}
                  className="w-full h-[400px] object-cover mb-4 cursor-pointer"
                  transition={{ duration: 0.3 }}
                  onClick={handleImageClick}
                />
                <div className="absolute top-1/2 transform -translate-y-1/2 left-0">
                  <button className="bg-gray-800 text-white p-2 rounded-full" onClick={handlePreviousImage}>
                    <FiChevronLeft className="h-6 w-6" />
                  </button>
                </div>
                <div className="absolute top-1/2 transform -translate-y-1/2 right-0">
                  <button className="bg-gray-800 text-white p-2 rounded-full" onClick={handleNextImage}>
                    <FiChevronRight className="h-6 w-6" />
                  </button>
                </div>
              </>
            ) : (
              <div className="h-48 w-full bg-gray-200 mb-4 rounded flex items-center justify-center text-gray-500">
                No Image
              </div>
            )}
          </div>
        </div>
        <div className="w-full lg:w-1/2 ">
          <h2 className="text-xl font-bold mb-4">{product.name}</h2>
          <div className="flex items-center mb-4">
            {product.originalPrice && (
              <span className="text-red-500 font-bold line-through mr-4">Rs.{product.originalPrice}</span>
            )}
            <span className="text-green-500 text-2xl">Rs.{product.price}</span>
          </div>
          <p className="text-lg font-medium text-gray-700 mb-1">Available Quantity : {product.stock}</p>
          <div className="text-gray-500 mb-4" dangerouslySetInnerHTML={{ __html: product.description }}></div>
          <div className="mb-4">
            <h3 className="text-lg font-medium mb-2">Select Size</h3>
            <div className="flex flex-wrap">
  {Array.isArray(product.sizes) && product.sizes.map((size, index) => (
    <label key={index} className="mr-4 mb-2">
      <input
        type="checkbox"
        className="mr-1"
        checked={selectedSize.value === size.value}
        onChange={() => setSelectedSize(size)}
      />
      {size.label}
    </label>
  ))}
</div>

          </div>
          <div className="mb-4">
            <h3 className="text-lg font-medium mb-2">Select Color</h3>
            <div className="flex flex-wrap">
  {Array.isArray(product.colors) && product.colors.map((color, index) => (
    <label key={index} className="mr-4 mb-2">
      <input
        type="checkbox"
        className="mr-1"
        checked={selectedColor.value === color.value}
        onChange={() => setSelectedColor(color)}
      />
      {color.label}
    </label>
  ))}
</div>

          </div>
          <button className="bg-teal-500 text-white py-2 px-4 rounded-md" onClick={() => handleAddToCart(product)}>
            Add to cart
          </button>
        </div>
      </div>

      <div className="mt-12">
        {/* Tab Navigation */}
        <div className="flex mb-6">
          <button
            className={`px-4 py-2 rounded-t-lg ${activeTab === 'description' ? 'bg-white text-black' : 'bg-gray-200 text-gray-600'}`}
            onClick={() => setActiveTab('description')}
          >
            Description
          </button>
          <button
            className={`px-4 py-2 rounded-t-lg ${activeTab === 'shipping' ? 'bg-white text-black' : 'bg-gray-200 text-gray-600'}`}
            onClick={() => setActiveTab('shipping')}
          >
            Shipping & Delivery
          </button>
        </div>

        {/* Tab Content */}
        <div className="bg-white p-6 rounded-b-lg shadow-md">
          {activeTab === 'description' && (
            <div dangerouslySetInnerHTML={{ __html: product.description }} />
          )}
          {activeTab === 'shipping' && (
            <div>
              <h3 className="font-bold text-lg mb-4">Shipping & Delivery</h3>
              <p>
                At PakStyle.pk, we prioritize delivering your purchases swiftly and securely.
                Once your order is confirmed, our dedicated team works diligently to process and
                package your items with care. We partner with reliable logistics companies to
                ensure timely delivery at your doorstep.
              </p>
              <h4 className="font-semibold text-md mt-4">Shipping Charges</h4>
              <ul className="list-disc pl-5">
                <li>Rs.100/- shipping & handling charges usually applied per item.</li>
                <li>If you order multiple items, 50% off will be applied on shipping charges.</li>
              </ul>
              <h4 className="font-semibold text-md mt-4">Delivery Time</h4>
              <ul className="list-disc pl-5">
                <li>2 to 3 business days in major cities like Karachi, Lahore, Islamabad, etc.</li>
                <li>3 to 5 business days in small towns and cities.</li>
                <li>5 to 8 business days in Chak & Villages.</li>
              </ul>
              <h4 className="font-semibold text-md mt-4">Logistics Partners</h4>
              <ul className="list-disc pl-5">
                <li>Leopards Courier, PostEx, Pakistan Post and Local Riders for Karachi Only.</li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* <div className="mt-12">
        <h3 className="text-2xl font-semibold mb-6">Related Products</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {relatedProducts.map((relatedProduct) => (
            <div
              key={relatedProduct.id}
              className="bg-white shadow-md rounded-lg relative cursor-pointer p-4"
              onClick={() => handleRelatedProductClick(relatedProduct.id)}
            >
              {relatedProduct.images && relatedProduct.images.length > 0 ? (
                <motion.img
                  src={getImageUrl(relatedProduct.images[0].url)}
                  alt={relatedProduct.name}
                  className="h-40 w-full object-cover mb-4 rounded"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.3 }}
                  onError={(e) => { e.target.onerror = null; e.target.src = '/default-image.png'; }} // Fallback image
                />
              ) : (
                <div className="h-40 w-full bg-gray-200 mb-4 rounded flex items-center justify-center text-gray-500">
                  No Image
                </div>
              )}
              <div className="absolute top-2 right-2">
                <FiPlusCircle className="h-6 w-6 text-teal-500 cursor-pointer" onClick={(e) => {
                  e.stopPropagation();
                  handleAddToCart(relatedProduct);
                }} />
              </div>
              <div className="grid grid-cols-2">
                <div>
                  <h3 className="text-xl mb-2 overflow-hidden text-ellipsis whitespace-nowrap">{relatedProduct.name}</h3>
                  <p className="text-lg font-medium text-gray-700 mb-1">Rs.{relatedProduct.price}</p>
                </div>
                <div>
                  <p className="text-lg font-medium text-gray-700 mb-1">Quantity: {relatedProduct.stock}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div> */}

      <ToastContainer />
      {isModalOpen && (
        <ImageModal
          imageUrl={getImageUrl(product.images[currentImageIndex].url)}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
};

export default ProductPage;
